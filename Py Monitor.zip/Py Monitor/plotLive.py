# Plot a graph of Data which is comming in on the fly
# Author: Norbert Feurle - Modified for Thingy 52 samples by Brennan Ho
# Commandline arguments format - argv[1] -> fileName, argv[2] -> numsamples, argv[3] -> port

from math import *
from collectSerial import *
import time, threading, pylab
import random as rand
import numpy as np

class LivePlotter():
    def __init__(self, index, offset, color, name):
      self.offset = offset
      self.yValues = 100 * [0] 
      self.plot = pylab.subplot(3,1,index)
      self.plot.grid(True)
      self.plotLive = self.plot.plot(pylab.arange(-10,0,0.1), pylab.array([0]*100), color=color, label="Average:" + str(round(np.average(self.yValues),2)) + "\nStd: " + str(round(np.std(self.yValues),2)))
      self.legend = self.plot.legend(loc='upper right')
      pylab.xlabel('time (s)')
      pylab.ylabel(name)

    def renewPlot(self, xAxis):
      self.plotLive[0].set_data(xAxis,pylab.array(self.yValues[-100:]))
      self.plot.axis([xAxis.min(),xAxis.max(),min(self.yValues) - self.offset,max(self.yValues) + self.offset])
      self.legend.get_texts()[0].set_text("Avg:" + str(round(np.average(self.yValues[100:]),2)) + "\nStd: " + str(round(np.std(self.yValues[100:]),2)))

    def addValues(self, val):
      self.yValues.append(val)

def producer(writer):
  global samples, powerPlot, currentPlot, busPlot, timeout, timer, recordingsFile, seconds

  fileData = []
  while time.time() <= timeout:
    data = parseData(listenSerial(comPort))
    data[1] = float(data[1]) * 0.0001
    busPlot.addValues(float(data[0]))
    currentPlot.addValues(float(data[1]))
    powerPlot.addValues(float(data[0]) * float(data[1]))
    data.append(str(round(float(data[0]) * float(data[1]),3)))
    fileData.append(data)
    samples += 1

  fileData[0] = fileData[0] + [str(i) for i in [samples, numpy.average(busPlot.yValues[100:]), numpy.average(currentPlot.yValues[100:]), numpy.average(powerPlot.yValues[100:]) * float(seconds), numpy.average(powerPlot.yValues[100:]), sum(powerPlot.yValues[100:]) * float(seconds), sum(powerPlot.yValues[100:])]]

  writer.writerows(fileData)
  writer.writerow(['L',samples,round(float(timeout-timestart),3)])
  recordingsFile.close()
  timer.stop()


#Used for callback function, writes data to file as well as plotting live
def RealtimePlotter(arg):
  global comPort, timeout, timestart, samples, busPlot, currentPlot, powerPlot, prevTime, seconds

  try:
    time.sleep(0.001)
    CurrentXAxis = np.linspace(prevTime - timestart, time.time() - timestart, 100)
    busPlot.renewPlot(CurrentXAxis)
    currentPlot.renewPlot(CurrentXAxis)
    powerPlot.renewPlot(CurrentXAxis)
    pylab.suptitle("Samples: " + str(samples) + "\nTime: " + str(round(time.time() - timestart,2)) + "\n Samples/sec: " + str(round(samples/(time.time()-timestart),3)) + "\n Total energy (J): " + str(sum(powerPlot.yValues)*(time.time()-timestart)/1000))  
    manager.canvas.draw()
  except:
    pass
  prevTime = time.time()

try:
  comPort = serial.Serial(port=sys.argv[3],baudrate=115200, bytesize=8, parity='N', stopbits=1)
  recordingsFile = open(sys.argv[1],"w",newline='')
  seconds = float(sys.argv[2])
except:
  print("Incorrect format:\n[python3] plotLive.py 'filename' 'time (s)' 'serial port'")

fig = pylab.figure()
manager = pylab.get_current_fig_manager()
samples = 0

busPlot = LivePlotter(1, 0.5, 'blue', 'Bus Voltage (V)') #Volts
currentPlot = LivePlotter(2, 1, 'red', 'Current (mA)') #Milliamps
powerPlot = LivePlotter(3, 10, 'purple', 'Power (mW)') #Milliwatts

writer = csv.writer(recordingsFile)
writer.writerow(['Bus Voltage (V)','Current (mA)', 'Power (mW)', 'Samples', 'Average Bus Voltage (V)', 'Average Current (mA)', 'Average Energy (J)', 'Average Power (mW)', 'Total Energy (J)', 'Total Power(mW)'])

#First read to port will cause a delay
throwAway = parseData(listenSerial(comPort))

timeout = time.time() + seconds
timestart = time.time()
prevTime = timestart
producerThread = threading.Thread(target=producer, args=(writer,))
producerThread.start()

timer = fig.canvas.new_timer(interval=0)
timer.add_callback(RealtimePlotter, ())
timer.start()

pylab.show()