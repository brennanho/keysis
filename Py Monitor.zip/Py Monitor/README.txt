PyMonitor designed to monitor, record, and plot serial data. 

Note: collectSerial writes data to each line in the csv with the format [busVolt, shuntVolt] and calculates current and power from these 2 values. Plotting the data must load a file with this exact format.

Examples:

1. collectSerial.py 
	-'python3 collectSerial.py testfile.csv 3 COM3' will write serial data from port 'COM3' to 'testfile.csv' for 3 seconds
2. graphData.py 
	-'python3 graphData.py testfile.csv' will plots (4 plots) versus time from data in testfile.csv
3. graphLive.py 
	-'python3 graphLive.py testfile.csv 3 COM3' will plot live serial data in addition to writing the data to a file as like in collectSerial.py  