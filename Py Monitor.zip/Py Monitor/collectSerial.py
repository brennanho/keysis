#Commandline arguments format : argv[1] -> filename, argv[2] -> seconds, argv[3] -> port
#This script is for reading data from a serial port then parsing and writing it to a file
import serial, re, sys, time, os, csv, numpy, serial.tools.list_ports

#Read from serial port and return each line
def listenSerial(comPort):
	try:
		return comPort.readline()
	except:
		pass

#Parses data read from serial port into a list of strings representing each numerical reading
def parseData(data):
	return re.findall(r"[-+]?\d*\.\d+|\d+", str(data)) # [seconds, busVolt, shuntVolt, current, power]

#Log data to 'fileName' for 'seconds' amount of time on port 
def writeToFile(fileName, seconds, port):
	
	try:
		comPort = serial.Serial(port=port,baudrate=115200, bytesize=8, parity='N', stopbits=1)
	except:
		print("Bad port:", port)
		sys.exit(1)

	readingsFile = open(fileName,"w",newline='')
	writer = csv.writer(readingsFile)
	
	print("Collecting serial data...")

	# collect data for argv[2] time (seconds) 
	busVolts = []
	currents = []
	powers = []
	fileData = []


	throwaway = parseData(listenSerial(comPort)) #There is a delay on the first comPort.readline(), therefore do not start timer until after this
	writer.writerow(['Bus Voltage (V)','Current (mA)', 'Power (mW)', 'Samples', 'Average Bus Voltage (V)', 'Average Current (mA)', 'Average Energy (J)', 'Average Power (mW)', 'Total Energy (J)', 'Total Power(mW)'])
	timestart = time.time()
	timeout = time.time() + float(seconds)
	samples = 0

	while time.time() <= timeout:
		dataList = parseData(listenSerial(comPort))
		dataList[1] = str(float(dataList[1]) * 0.001)
		dataList.append(str(round(float(dataList[0]) * float(dataList[1]),3)))
		busVolts.append(float(dataList[0]))
		currents.append(float(dataList[1]))
		powers.append(float(dataList[2]))
		fileData.append(dataList)
		samples += 1

	fileData[0] = fileData[0] + [str(i) for i in [samples, numpy.average(busVolts), numpy.average(currents), numpy.average(powers) * float(seconds), numpy.average(powers), sum(powers) * float(seconds), sum(powers)]]

	writer.writerows(fileData)
	writer.writerow(['L',samples,float(seconds)])
	readingsFile.close()
	comPort.close()
	print("Complete:", samples,"samples collected in", float(seconds), "seconds")

if __name__ == "__main__":
	#print(serial.tools.list_ports.comports())
	if (len(sys.argv) == 2):
		writeToFile("2secs.csv", 2, sys.argv[1])
		writeToFile("10secs.csv", 10, sys.argv[1])
		writeToFile("30secs.csv", 30, sys.argv[1])
	else:
		try:
			writeToFile(sys.argv[1], sys.argv[2], sys.argv[3])
		except IndexError:
			print("Incorrect format:\n[python3] collectSerial.py 'filename' 'time' 'serial port'")