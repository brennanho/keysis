import sys, re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.widgets as widget
import matplotlib.animation as animation

class Plotter():
    def __init__(self, index, xValues, yValues, name, units, color):
        self.index = index
        self.units = units
        self.xValues = xValues
        self.yValues = yValues
        self.currentX = 0
        self.currentY = 0
        self.name = name
        self.color = color
        self.plot = plt.subplot(3, 1, self.index)
        self.plot.grid(True)
        self.plotL = self.plot.plot(np.unique(self.xValues), np.poly1d(np.polyfit(self.xValues, self.yValues, 1))(np.unique(self.xValues)),color='grey')
        self.plot.plot(xValues, yValues, '-',color=self.color,scalex=False, label="Average: " + str(round(np.average(self.yValues),2)) + "\nStd: " + str(round(np.std(self.yValues),2)))
        self.plot.legend(loc='upper right')
        plt.xlabel('time (s)')
        plt.ylabel(self.name + self.units)

    def findNearest(self, array, value):
	    array = np.asarray(array)
	    idx = (np.abs(array - value)).argmin()
	    return array[idx]

    def updateVerticalLine(self, xval):
    	global fig
    	self.plot.lines = self.plot.lines[:2]
    	try:
    		self.plot.axvline(x=xval, color="red")
    		xVals1 = self.plot.lines[1].get_data()[0]
    		nearestX = self.findNearest(xVals1, xval)
    		index = np.where(xVals1==nearestX)
    		self.currentY = round(self.plot.lines[1].get_data()[1][index][0],3)
    		self.currentX = round(xval,3)
    		self.plot.legend(loc='upper right',bbox_to_anchor=(1.1, 1.05)).get_texts()[0].set_text("Average: " + str(round(np.average(self.yValues),2)) + "\nStd: " + str(round(np.std(self.yValues),2)) + "\n[t:" + str(self.currentX) + "," + self.name + ": " + str(self.currentY) + "]")
    	except:
    		pass

    def updatePlot(self, val):
    	global plotSlider
    	self.plot.axis([min(x for x in self.xValues if x > plotSlider.val) + plotSlider.val, max(x for x in self.xValues if x < 0.1 + plotSlider.val) + plotSlider.val, min(self.yValues),max(self.yValues)])

def updateSlider(val):
	global currentPlot, busPlot, powerPlot 
	currentPlot.updatePlot(val)
	busPlot.updatePlot(val)
	powerPlot.updatePlot(val)

def mouseHover(event):
	global currentPlot, busPlot, powerPlot, fig
	busPlot.updateVerticalLine(event.xdata)
	currentPlot.updateVerticalLine(event.xdata)
	powerPlot.updateVerticalLine(event.xdata)

def plotMain(file):
	#List of various recorded data
	global currentPlot, busPlot, powerPlot, plotSlider, fig
	samples = 0
	timeout = 0
	busVolt = []
	current = []
	power = []

	#Open file containing recorded serial data and parse them into their respective lists
	with open(file) as dataFile:
		for line in dataFile:
			dataList = re.findall(r"[-+]?\d*\.\d+|\d+", line) # Regex
			if line[0] == 'L': #Last line
				samples = int(dataList[0])
				timeout = float(dataList[1])
				break
			try:
				dataList = [np.float32(i) for i in dataList] # [busVolt, current, power]
				busVolt.append(dataList[0])
				current.append(dataList[1])
				power.append(dataList[2])
			except:
				pass

	print("Number of samples: ", samples)
	print("Avg Bus Voltage: ", np.average(busVolt), " (V)")
	print("Avg Current: ", np.average(current), " (mA)") 
	print("Avg Power: ", np.average(power), " (mW)")
	print("Total Power: ", sum(power)," (mW)")
	print("Average Energy: ", np.average(power) * float(timeout), " (mJ)")
	print("Total Energy: ", sum(power) * float(timeout), " (mJ)")

	time = np.linspace(0.0, timeout, num=samples)

	fig = plt.figure(file)
	busPlot = Plotter(1, time, busVolt, 'Bus Voltage', "(V)", 'blue')
	currentPlot = Plotter(2, time, current, 'Current', "(mA)", 'green')
	powerPlot = Plotter(3, time, power, 'Power', "(mW)", 'purple')
	plt.suptitle("Samples: " + str(samples) + "\n Samples/sec: " + str(round(samples/timeout,3)) + "\n Total energy (J): " + str(round(sum(powerPlot.yValues)*timeout/1000,5)))

	#Slider for scrolling through time on x axis
	plotSlider = widget.Slider( plt.axes([0.25,0.9,0.5,0.01]) , 'Time', 0, timeout/2)
	plotSlider.on_changed(updateSlider)
	fig.canvas.mpl_connect('motion_notify_event',mouseHover)
	ani = animation.FuncAnimation(fig, lambda i: i, interval=1) #Must pass in updater function
	plt.show()

if __name__ == "__main__":
	try:
		plotMain(sys.argv[1])
	except IndexError:
		print("Incorrect format:\n[python3] plotData.py 'filename'")
	except:
		print("File not found:\n",sys.argv[1])