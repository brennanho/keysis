1 Ohm Resistor: no gain
10 Ohm Resistor: gain level 2