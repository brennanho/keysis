#!/usr/bin/env python
# Plot a graph of Data which is comming in on the fly
# uses pylab
# Author: Norbert Feurle - Modified for Thingy 52 readings by Brennan Ho
# Date: 12.1.2012
# License: if you get any profit from this then please share it with me

import pylab
from math import *
from collectSerial import *
import random as rand
import numpy as np

xAxis = pylab.arange(0,10,0.1)
yAxis = pylab.array([0]*100) 

fig = pylab.figure(1,figsize=(10,10))
graph = fig.add_subplot(111)
graph.grid(True) #Create grid blocks in background
graph.set_xlabel("Time")
graph.set_ylabel("Voltage")
#graph.axis([0,0, 0, 1])

busVoltsL = graph.plot(xAxis,yAxis,'-',label='Bus Voltage')
shuntVoltsL = graph.plot(xAxis,yAxis,'-',label='Shunt Voltage')
currentL = graph.plot(xAxis,yAxis,'-',label='Current')
energyL = graph.plot(xAxis,yAxis,'-',label='Energy')
graph.legend(loc="upper left")
manager = pylab.get_current_fig_manager()

#Renew every 100 datapoints (circular array to simulate continuous data)
busVolts = [0 for x in range(100)]
shuntVolts = [0 for x in range(100)]
current = [0 for x in range(100)]
energy = [0 for x in range(100)]
time = [0 for x in range(100)]

comPort = ''
if os.name == 'nt':
  comPort = serial.Serial(port='COM3',baudrate=115200, bytesize=8, parity='N', stopbits=1)
else:
  comPort = serial.Serial(port='/dev/ttyUSB0',baudrate=115200, bytesize=8, parity='N', stopbits=1)


def RealtimePloter(arg):
  #Data retrieved from serial port
  global comPort
  
  try:
    data = parseData(listenSerial(comPort))
    data = [np.float64(i) for i in data]
    time.append(data[0])
    busVolts.append(data[1])
    shuntVolts.append(data[2])
    current.append(data[3])
    energy.append(data[4])
    print(data)
  except:
    pass


  #Update plot with busVolts and draw to canvas
  CurrentXAxis = pylab.arange(ceil((len(busVolts)-100)/10),ceil(len(busVolts)/10),0.1)
  #CurrentXAxis = pylab.array(time[-100:])
  busVoltsL[0].set_data(CurrentXAxis,pylab.array(busVolts[-100:]))
  shuntVoltsL[0].set_data(CurrentXAxis,pylab.array(shuntVolts[-100:]))
  currentL[0].set_data(CurrentXAxis,pylab.array(current[-100:]))
  energyL[0].set_data(CurrentXAxis,pylab.array(energy[-100:]))
  graph.axis([CurrentXAxis.min(),CurrentXAxis.max(),-1.0,10])
  manager.canvas.draw()

timer = fig.canvas.new_timer(interval=0)
timer.add_callback(RealtimePloter, ())
timer.start()

pylab.show()