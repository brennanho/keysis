#Format : "script filename seconds"
#E.G. call "python3 collectSerial.py test.txt 3"

#This script is for reading data from a serial port then parsing and writing it to a file
import serial, re, sys, time, os, csv

#Read from serial port and return each line
def listenSerial(comPort):
	try:
		data = comPort.readline()
		return data
	except:
		pass

#Parses data read from serial port into a list of strings representing each numerical reading
def parseData(data):
	return re.findall(r"[-+]?\d*\.\d+|\d+", str(data)) # [seconds, busVolt, shuntVolt, current, power]

#Log data to 'fileName' for 'seconds' amount of time
def writeToFile(fileName, seconds):
	comPort = ''

	if os.name == 'nt': #Windows
		comPort = serial.Serial(port='COM3',baudrate=115200, bytesize=8, parity='N', stopbits=1)
	else:
		comPort = serial.Serial(port='/dev/ttyUSB0',baudrate=115200, bytesize=8, parity='N', stopbits=1)

	readingsFile = open(fileName,"w",newline='')
	writer = csv.writer(readingsFile)
	
	# collect data for argv[2] time (seconds)
	timeout = time.time() + int(seconds) 

	while time.time() <= timeout:
		dataList = parseData(listenSerial(comPort))
		if (len(dataList) == 5):
			print(dataList)
			writer.writerow(dataList)

	readingsFile.close()

if __name__ == "__main__":
	writeToFile(sys.argv[1], sys.argv[2])