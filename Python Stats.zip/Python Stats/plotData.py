import numpy as np
import sys, re
import matplotlib.pyplot as plt
import matplotlib.widgets as widget

class PlotMaker():
    def __init__(self, index, xValues, yValues, name, color):
        self.index = index
        self.xValues = xValues
        self.yValues = yValues
        self.name = name
        self.color = color
        self.plot = plt.subplot(4, 1, self.index)
        self.plot.grid(True)
        self.plot.plot(np.unique(self.xValues), np.poly1d(np.polyfit(self.xValues, self.yValues, 1))(np.unique(self.xValues)),color='grey')
        self.plot.plot(xValues, yValues, '-',color=self.color,scalex=False)
        plt.xlabel('time (s)')
        plt.ylabel(self.name)

#List of various recorded data
busVolt = []
shuntVolt = []
current = []
energy = []
totalEnergy = 0
totalPower = 0

#Open file containing recorded serial data and parse them into their respective lists
with open(sys.argv[1]) as dataFile:
	for line in dataFile:
		dataList = re.findall(r"[-+]?\d*\.\d+|\d+", line) # Regex
		dataList = [np.float64(i) for i in dataList] # [busVolt, shuntVolt, loadVolt, current, energy]
		busVolt.append(dataList[1])
		shuntVolt.append(dataList[2])
		current.append(dataList[3])
		energy.append(dataList[4])
		totalEnergy += dataList[4]

#Compute the averages for each data type
avgBusvolt = sum(busVolt) / np.float64(len(busVolt))
avgShuntvolt = sum(shuntVolt) / np.float64(len(shuntVolt))
avgCurrent = sum(current) / np.float64(len(current))
avgEnergy = sum(energy) / np.float64(len(energy))

print("Number of readings: ", dataList[0] + 1)
print("Avg Bus Voltage: ", avgBusvolt, " (V)")
print("Avg Shunt Voltage: ", avgShuntvolt, " (mV)")
print("Avg Current: ", avgCurrent, " (mA)") 
print("Avg Energy: ", avgEnergy, " (Watts)")
print("Total Energy: ", totalEnergy," (Watts)")
print("Total Power: ", totalPower, " (Joules)")

time = np.linspace(0.0, 2, num=len(busVolt))
plt.subplots(4,1, figsize=(15,15)) # Size of window and number of plots = 2 * 2

busPlot = PlotMaker(1, time, busVolt, 'Bus Voltage (V)', 'blue')
shuntPlot = PlotMaker(2, time, shuntVolt, 'Shunt Voltage (mV)', 'red')
currentPlot = PlotMaker(3, time, current, 'Current (mA)', 'green')
energyPlot = PlotMaker(4, time, energy, 'Energy (W)', 'purple')

activePlot = busPlot
activeData = busVolt

#Slider for scrolling through time on x axis
axpos = plt.axes([0.25,0.9,0.5,0.01])
plotSlider = widget.Slider(axpos, 'Time', 0.0, 2.0)

#Radio buttons for different plots
rax = plt.axes([0.1,0.89,0.1,0.1])
optionsButton = widget.RadioButtons(rax, ('Bus Voltage', 'Shunt Voltage', 'Current', 'Energy'))

def plotSelect(plotLabel):
	global activePlot, busPlot, shuntPlot, energyPlot, currentPlot
	if plotLabel == 'Bus Voltage':
		activePlot = busPlot
	elif plotLabel == 'Shunt Voltage':
		activePlot = shuntPlot
	elif plotLabel == 'Energy':
		activePlot = energyPlot
	else:
		activePlot = currentPlot

def updateSlider(val):
	global activePlot
	activePlot.plot.axis([min(x for x in time if x > plotSlider.val) + plotSlider.val, max(x for x in time if x < 1 + plotSlider.val) + plotSlider.val, min(activePlot.yValues),max(activePlot.yValues)])
	#activePlot.axis([min(time), max(time), min(activeData),max(activeData)])


for i in range(len(time)-1):
	print(time[i+1]-time[i])

plotSlider.on_changed(updateSlider)
optionsButton.on_clicked(plotSelect)
plt.show()